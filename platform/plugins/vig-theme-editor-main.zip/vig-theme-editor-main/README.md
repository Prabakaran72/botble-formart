# vig-theme-editor
Botble CMS - Plugin edit file theme in Admin Panel

## Enable/Disable Plugin in .env

VIG_THEME_EDITOR_ENABLE=true

<img width="1709" alt="image" src="https://i.ibb.co/mBDnZS0/image.png">

