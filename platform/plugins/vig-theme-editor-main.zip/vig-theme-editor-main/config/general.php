<?php

return [
    'enable' => env('VIG_THEME_EDITOR_ENABLE', false),
];
