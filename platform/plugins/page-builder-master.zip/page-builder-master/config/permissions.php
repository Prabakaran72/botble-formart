<?php

return [
    [
        'name' => 'Page Builder',
        'flag' => 'page_builder.design',
    ],
];