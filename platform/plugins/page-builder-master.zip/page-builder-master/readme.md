# Important note
Page builder plugin is just worked on Botble CMS <= 5.15 due to issue with CKEditor 5 on the version > 5.15.

# Overview
This is a plugin for Botble CMS so you have to purchase Botble CMS first to use this plugin. 
Purchase it here: [https://codecanyon.net/item/botble-cms-php-platform-based-on-laravel-framework/16928182](https://1.envato.market/LWRBY)

# Installation
- Download and rename folder `page-builder-master` to `page-builder`.
- Copy folder `page-builder` into `/platform/plugins`.
- Go to Admin -> Plugins then activate plugin Page Builder.

# Screenshots

![Screenshot](https://raw.githubusercontent.com/botble/page-builder/master/public/images/screenshot-1.png)

![Screenshot](https://raw.githubusercontent.com/botble/page-builder/master/public/images/screenshot-2.png)

# Contact us
- Website: [https://botble.com](https://botble.com)
- Email: [contact@botble.com](mailto:contact@botble.com)
