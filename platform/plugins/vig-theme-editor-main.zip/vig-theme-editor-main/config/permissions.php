<?php

return [
    [
        'name' => 'Vig theme editors',
        'flag' => 'vig-theme-editor',
    ],
];
