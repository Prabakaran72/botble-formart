<?php

return [
    'edit_in_designer' => 'Edit in designer',
    'save' => 'Save',
];
