<?php

return [
    'name' => 'Theme File Editor',
    'submit' => 'Submit',
    'error' => 'Error save file not writable',
    'success' => 'Success save file',
    'enable_title' => 'Please enable in .env',
    'enable_description' => 'To ensure your safety. Please go to .env and add VIG_THEME_EDITOR_ENABLE=true to use this function and after done VIG_THEME_EDITOR_ENABLE=false to turn it off'
];
