<span class="editor-action-item">
    <a href="{{ route('page_builder.design', $id) }}" class="btn btn-info">
        <i class="fas fa-paint-brush"></i> {{ trans('plugins/page-builder::page-builder.edit_in_designer') }}
    </a>
</span>